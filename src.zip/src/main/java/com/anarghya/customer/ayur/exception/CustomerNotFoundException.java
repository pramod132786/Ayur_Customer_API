package com.anarghya.customer.ayur.exception;

public class CustomerNotFoundException extends Exception{
	
	public CustomerNotFoundException(String s) {
		super(s);
	}

}
