package com.anarghya.customer.ayur;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnarghyaAyurCustomerApplicationTests {

	@Test
	void contextLoads() {
	}

}
